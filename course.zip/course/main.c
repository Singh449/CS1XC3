/**
 * @file main.c
 * @author singh42
 * @date 12 th April 2022
 * @brief This basically explains about the course and the student libraries.
 */  
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // This is enrolling 20 students (random students)
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));

  // Printing the course information
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);

  // Prints top student
  printf("\n\nTop student: \n\n");
  print_student(student);
  
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  
  // Prints the total passing marks and students.
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}